package com.daniel.mood

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.*
import kotlin.math.max

private val namesEn = listOf("Happy", "Sad", "Calm", "Energetic & Workout", "Romantic", "Rainy & Nostalgic", "Focus & Study", "Night & Dreamy", "Party & Dance", "Road Trip", "Morning Boost", "Sleep", "Unsorted")
private val namesFa = listOf("شاد", "غمگین", "آرام", "انرژی‌بخش و ورزش", "رمانتیک", "بارانی و نوستالژیک", "تمرکز و مطالعه", "شبانه و رؤیایی", "مهمانی و رقص", "سفر و جاده", "صبح پرانرژی", "خواب و آرامش عمیق", "دسته‌بندی‌نشده")
private val icons = listOf("☀", "☔", "🌿", "⚡", "♥", "☁", "✎", "☾", "♫", "🚗", "🌅", "☽", "?")
private fun moodName(id: Int, fa: Boolean) = (if (fa) namesFa else namesEn).getOrElse(id) { "?" }
private fun tr(fa: Boolean, en: String, persian: String) = if(fa) persian else en
private fun digits(value: Any, faDigits: Boolean): String = value.toString().let { if (!faDigits) it else it.map { c -> if(c in '0'..'9') ('۰'.code+c.code-'0'.code).toChar() else c }.joinToString("") }
private fun clock(ms: Long, pd: Boolean): String { val s = max(0, ms/1000); return digits("${s/60}:${(s%60).toString().padStart(2,'0')}", pd) }

class MainActivity : ComponentActivity() {
    private var permissionChanged by mutableIntStateOf(0)
    private val requestPermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissionChanged++ }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(onRequest = {
            val p = mutableListOf(if(Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
            if(Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions.launch(p.toTypedArray())
        }, permissionTick = permissionChanged) }
    }
    override fun onResume() { super.onResume(); permissionChanged++ }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun App(onRequest: ()->Unit, permissionTick: Int) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("settings", 0) }
    var fa by remember { mutableStateOf(prefs.getBoolean("fa", true)) }
    var persianDigits by remember { mutableStateOf(prefs.getBoolean("digits", true)) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    val pd = fa && persianDigits
    var page by remember { mutableStateOf("home") }
    var category by remember { mutableIntStateOf(-1) }
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableIntStateOf(0) }
    var offset by remember { mutableIntStateOf(0) }
    var correction by remember { mutableStateOf<Song?>(null) }
    var onboarding by remember { mutableStateOf(!prefs.getBoolean("batterySeen", false)) }
    var benchmark by remember { mutableStateOf("") }
    var playerOpen by remember { mutableStateOf(false) }
    var playerRevision by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val dao = remember { MoodDatabase.get(context).songs() }
    val progress by ScanState.progress.collectAsState()
    val counts by dao.counts().collectAsState(initial = emptyList())
    val total = counts.sumOf { it.count }
    val permission = remember(permissionTick) { ContextCompat.checkSelfPermission(context, if(Build.VERSION.SDK_INT>=33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(context) {
        val future = MediaController.Builder(context, SessionToken(context, ComponentName(context, PlaybackService::class.java))).buildAsync()
        future.addListener({ try { controller = future.get() } catch (_: Exception) {} }, ContextCompat.getMainExecutor(context))
        onDispose { MediaController.releaseFuture(future) }
    }
    LaunchedEffect(controller) { while (true) { delay(500); playerRevision++ } }
    fun scan(action: String? = null) {
        try {
            val i = Intent(context, ScanService::class.java).apply { this.action = action }
            if(action == null) ContextCompat.startForegroundService(context, i) else context.startService(i)
        } catch (_: Exception) { ScanState.update { it.copy(error="service") } }
    }
    fun play(songs: List<Song>, first: Int = 0, shuffle: Boolean = false) {
        val c = controller ?: return
        try {
            val tracks = songs.map { s -> MediaItem.Builder().setMediaId(s.id.toString()).setUri(s.uri).setMediaMetadata(MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).build()).build() }
            if(tracks.isNotEmpty()) { c.setMediaItems(tracks, first.coerceIn(0, tracks.lastIndex), 0); c.shuffleModeEnabled = shuffle; c.prepare(); c.play() }
        } catch (_: Exception) { }
    }
    CompositionLocalProvider(LocalLayoutDirection provides if(fa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        MaterialTheme(colorScheme = if(dark) darkColorScheme() else lightColorScheme(), typography = Typography().let { base ->
            val font = FontFamily(Font(R.font.persian)); base.copy(bodyLarge=base.bodyLarge.copy(fontFamily=font),bodyMedium=base.bodyMedium.copy(fontFamily=font),titleLarge=base.titleLarge.copy(fontFamily=font),titleMedium=base.titleMedium.copy(fontFamily=font),labelLarge=base.labelLarge.copy(fontFamily=font))
        }) {
            Scaffold(bottomBar = {
                val c = controller
                if (c != null && playerRevision >= 0 && c.currentMediaItem != null) Surface(tonalElevation=4.dp) {
                    Row(Modifier.fillMaxWidth().padding(horizontal=12.dp), horizontalArrangement=Arrangement.SpaceBetween) {
                        TextButton(onClick={playerOpen=true}, modifier=Modifier.weight(1f)) { Text(c.mediaMetadata.title?.toString() ?: "♫", maxLines=1, overflow=TextOverflow.Ellipsis) }
                        TextButton(onClick={ if(c.isPlaying) c.pause() else c.play(); playerRevision++ }) { Text(if(c.isPlaying) "❚❚" else "▶") }
                        TextButton(onClick={c.seekToNextMediaItem()}) { Text("⏭") }
                    }
                }
            }) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(tr(fa,"Mood Music Sorter","مرتب‌ساز موزیک بر اساس حال‌وهوا"), style=MaterialTheme.typography.titleMedium, modifier=Modifier.weight(1f))
                        TextButton(onClick={page="home"}) { Text(tr(fa,"Home","خانه")) }
                        TextButton(onClick={page="settings"}) { Text(tr(fa,"Settings","تنظیمات")) }
                    }
                    if(!permission) {
                        Text(tr(fa,"Allow access to your audio files to scan your library.","برای بررسی کتابخانه، دسترسی به فایل‌های صوتی را فعال کنید."))
                        Row { Button(onClick=onRequest) { Text(tr(fa,"Allow / retry","اجازه / تلاش دوباره")) }; TextButton(onClick={ try { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:${context.packageName}"))) } catch (_: Exception) {} }) { Text(tr(fa,"App settings","تنظیمات برنامه")) } }
                    }
                    if(progress.running) {
                        Text(tr(fa,"Scanning", "در حال بررسی") + " ${digits(progress.done,pd)} / ${digits(progress.discovered,pd)}  " + progress.current, maxLines=1, overflow=TextOverflow.Ellipsis)
                        if(progress.discovered > 0) LinearProgressIndicator(progress=(progress.done.toFloat()/progress.discovered).coerceIn(0f,1f), modifier=Modifier.fillMaxWidth())
                        else LinearProgressIndicator(modifier=Modifier.fillMaxWidth())
                        val elapsed = ((System.currentTimeMillis()-progress.started)/1000.0).coerceAtLeast(1.0)
                        val rate = progress.done / elapsed
                        val remaining = if(rate > 0) ((progress.discovered-progress.done).coerceAtLeast(0)/rate).toLong() else 0L
                        Text(tr(fa,"Songs/sec: ","آهنگ در ثانیه: ")+digits("%.1f".format(java.util.Locale.US,rate),pd)+"   "+tr(fa,"ETA: ","زمان تقریبی: ")+clock(remaining*1000,pd))
                        Row { TextButton(onClick={scan(if(progress.paused) "resume" else "pause")}) { Text(if(progress.paused) tr(fa,"Resume","ادامه") else tr(fa,"Pause","مکث")) }; TextButton(onClick={scan("cancel")}) { Text(tr(fa,"Cancel","لغو")) } }
                    }
                    if(progress.error.isNotBlank()) Text(tr(fa,"Scan stopped. Check permissions and try again.","بررسی متوقف شد. دسترسی‌ها را بررسی و دوباره تلاش کنید."),color=MaterialTheme.colorScheme.error)
                    when(page) {
                        "home" -> {
                            Row { Button(enabled=permission && !progress.running,onClick={scan()}) { Text(tr(fa,"Scan library","بررسی کتابخانه")) }; Spacer(Modifier.width(8.dp)); TextButton(onClick={category=-1;offset=0;page="songs"}) { Text(tr(fa,"All songs","همه آهنگ‌ها")+" (${digits(total,pd)})") } }
                            LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)) {
                                items(13) { id ->
                                    val count = counts.firstOrNull { it.mood==id }?.count ?: 0
                                    ElevatedCard(onClick={category=id;offset=0;page="songs"},modifier=Modifier.fillMaxWidth()) {
                                        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement=Arrangement.SpaceBetween) {
                                            Text("${icons[id]}  ${moodName(id,fa)}"); Text(digits(count,pd))
                                        }
                                    }
                                }
                            }
                        }
                        "songs" -> {
                            val songs by remember(category, query, sort, offset) { dao.page(category, query, sort, 100, offset) }.collectAsState(initial=emptyList())
                            Text(if(category<0) tr(fa,"All songs","همه آهنگ‌ها") else moodName(category,fa),style=MaterialTheme.typography.titleLarge)
                            OutlinedTextField(value=query,onValueChange={query=it;offset=0},label={Text(tr(fa,"Search title or artist","جستجوی نام یا خواننده"))},singleLine=true,modifier=Modifier.fillMaxWidth())
                            Row { TextButton(onClick={sort=(sort+1)%5;offset=0}) { Text(tr(fa,"Sort: ","ترتیب: ")+listOf(tr(fa,"title","نام"),tr(fa,"artist","خواننده"),tr(fa,"date","تاریخ"),"BPM",tr(fa,"energy","انرژی"))[sort]) }; TextButton(enabled=category != 12,onClick={ scope.launch { try { play(withContext(Dispatchers.IO) { dao.playlist(category) },0,true) } catch (_: Exception) {} } }) { Text(tr(fa,"Mood Mix ▶","پخش تصادفی ▶")) } }
                            LazyColumn(modifier=Modifier.weight(1f)) {
                                items(songs,key={it.id}) { song ->
                                    ElevatedCard(modifier=Modifier.fillMaxWidth().padding(vertical=3.dp),onClick={scope.launch { try { val list=withContext(Dispatchers.IO){dao.playlist(category)}; val i=list.indexOfFirst{it.id==song.id}; play(list,if(i<0) 0 else i) } catch (_:Exception) {} }}) {
                                        Column(Modifier.padding(10.dp)) {
                                            Text(song.title, maxLines=1, overflow=TextOverflow.Ellipsis,style=MaterialTheme.typography.titleMedium)
                                            Text("${song.artist}  ${clock(song.duration,pd)}  •  ${moodName(song.mood,fa)}")
                                            if(song.reason.isNotBlank()) Text(when(song.reason) { "silent" -> tr(fa,"Silent audio","فایل بی‌صدا"); "short" -> tr(fa,"Insufficient audio","صدای ناکافی"); "unsupported" -> tr(fa,"Unsupported format","قالب پشتیبانی نمی‌شود"); else -> tr(fa,"Unreadable or damaged audio","فایل ناخوانا یا آسیب‌دیده") })
                                            else Text(tr(fa,"Second: ","حالت دوم: ")+moodName(song.secondary,fa)+"  •  "+tr(fa,"confidence ","اطمینان ")+digits((song.confidence*100).toInt(),pd)+"%  •  "+digits(song.bpm.toInt(),pd)+" BPM")
                                            Row { TextButton(onClick={correction=song}) { Text(tr(fa,"Change mood","تغییر حال‌وهوا")) }; TextButton(enabled=!progress.running,onClick={scope.launch { withContext(Dispatchers.IO){dao.invalidate(song.id)}; scan() }}) { Text(tr(fa,"Reanalyze","تحلیل دوباره")) } }
                                        }
                                    }
                                }
                            }
                            Row(horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()) {
                                TextButton(enabled=offset>0,onClick={offset=max(0,offset-100)}) { Text(tr(fa,"Previous","قبلی")) }
                                Text(digits(offset+1,pd)+"–"+digits(offset+songs.size,pd))
                                TextButton(enabled=songs.size==100,onClick={offset+=100}) { Text(tr(fa,"Next","بعدی")) }
                            }
                        }
                        "settings" -> LazyColumn {
                            item { Text(tr(fa,"Settings","تنظیمات"),style=MaterialTheme.typography.titleLarge) }
                            item { TextButton(onClick={fa=!fa;prefs.edit().putBoolean("fa",fa).apply()}) { Text(if(fa) "Language: فارسی / English" else "Language: English / فارسی") } }
                            item { Row { Text(tr(fa,"Persian digits","اعداد فارسی"),modifier=Modifier.weight(1f)); Switch(checked=persianDigits,onCheckedChange={persianDigits=it;prefs.edit().putBoolean("digits",it).apply()}) } }
                            item { Row { Text(tr(fa,"Dark theme","پوسته تیره"),modifier=Modifier.weight(1f)); Switch(checked=dark,onCheckedChange={dark=it;prefs.edit().putBoolean("dark",it).apply()}) } }
                            item { var accurate by remember { mutableStateOf(prefs.getBoolean("accurate",false)) }; Row { Text(tr(fa,"Accurate analysis (slower)","تحلیل دقیق‌تر (کندتر)"),modifier=Modifier.weight(1f)); Switch(checked=accurate,onCheckedChange={accurate=it;prefs.edit().putBoolean("accurate",it).apply()}) } }
                            item { var minimum by remember { mutableIntStateOf(prefs.getInt("minSeconds",30)) }; TextButton(onClick={minimum=when(minimum){0->15;15->30;30->60;else->0};prefs.edit().putInt("minSeconds",minimum).apply()}) { Text(tr(fa,"Minimum duration: ","حداقل مدت: ")+digits(minimum,pd)+tr(fa," seconds"," ثانیه")) } }
                            item { TextButton(enabled=!progress.running,onClick={scope.launch { withContext(Dispatchers.IO){dao.invalidateAll()}; scan() }}) { Text(tr(fa,"Reanalyze all","تحلیل دوباره همه")) } }
                            item { TextButton(enabled=!progress.running,onClick={ scope.launch { benchmark=tr(fa,"Benchmark running…","در حال اندازه‌گیری…"); val result=withContext(Dispatchers.IO) { val list=dao.playlist(-1).take(20); val start=System.nanoTime(); var ok=0; for(s in list) try { AudioAnalysis.analyze(context,Uri.parse(s.uri),s.duration,false);ok++ } catch (_:Exception) {}; Pair(ok, (System.nanoTime()-start)/1_000_000) }; benchmark=tr(fa,"Completed / average milliseconds: ","تعداد موفق / میانگین میلی‌ثانیه: ")+digits(result.first,pd)+" / "+digits(if(result.first>0) result.second/result.first else 0,pd) } }) { Text(tr(fa,"Benchmark 20 songs","آزمون سرعت ۲۰ آهنگ")) }; Text(benchmark) }
                            item { TextButton(onClick={onboarding=true}) { Text(tr(fa,"Battery and MIUI help","راهنمای باتری و MIUI")) } }
                            item { Spacer(Modifier.height(12.dp)); Text(tr(fa,"About","درباره"),style=MaterialTheme.typography.titleMedium); Text(tr(fa,"Creator: Daniel Mousavi","سازنده: دانیال موسوی")) }
                            item { TextButton(onClick={try{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://instagram.com/dani.m7016")))}catch (_:Exception){}}) {Text("Instagram: dani.m7016")} }
                            item { TextButton(onClick={try{context.startActivity(Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:daniel.865559@gmail.com")))}catch (_:Exception){}}) {Text("daniel.865559@gmail.com")} }
                            item { Text(tr(fa,"Mood labels are estimates based on sound, not verified emotions.","حال‌وهوا تخمینی بر اساس صداست و تشخیص قطعی احساس نیست.")) }
                        }
                    }
                }
            }
            correction?.let { song -> AlertDialog(onDismissRequest={correction=null},title={Text(tr(fa,"Choose a mood","انتخاب حال‌وهوا"))},text={LazyColumn { items(12) { id -> TextButton(onClick={scope.launch { withContext(Dispatchers.IO){dao.correct(song.id,id)};correction=null }}) { Text("${icons[id]}  ${moodName(id,fa)}") } } }},confirmButton={TextButton(onClick={correction=null}){Text(tr(fa,"Close","بستن"))}}) }
            if(onboarding) AlertDialog(onDismissRequest={onboarding=false;prefs.edit().putBoolean("batterySeen",true).apply()},title={Text(tr(fa,"Keep analysis running","ادامه تحلیل در پس‌زمینه"))},text={Text(tr(fa,"Xiaomi may stop background tasks. In battery settings allow unrestricted battery use for this app. In MIUI/HyperOS app settings, enable autostart if available. You may skip this; if stopped, open the app and scan again to continue.","شیائومی ممکن است کارهای پس‌زمینه را متوقف کند. در تنظیمات باتری، مصرف باتری این برنامه را بدون محدودیت کنید. در MIUI یا HyperOS، در صورت وجود، شروع خودکار را فعال کنید. می‌توانید رد کنید؛ برای ادامه، برنامه را باز کرده و دوباره بررسی کنید."))},confirmButton={TextButton(onClick={try{context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))}catch(_:Exception){};onboarding=false;prefs.edit().putBoolean("batterySeen",true).apply()}){Text(tr(fa,"Open battery settings","تنظیمات باتری"))}},dismissButton={TextButton(onClick={onboarding=false;prefs.edit().putBoolean("batterySeen",true).apply()}){Text(tr(fa,"Skip","رد کردن"))}})
            if(playerOpen && controller != null) {
                val c=controller!!
                AlertDialog(onDismissRequest={playerOpen=false},title={Text(c.mediaMetadata.title?.toString() ?: "♫")},text={
                    Column {
                        Text(c.mediaMetadata.artist?.toString() ?: "")
                        val position = if(playerRevision >= 0) c.currentPosition.coerceAtLeast(0) else 0
                        val duration = c.duration.coerceAtLeast(0)
                        Slider(value=if(duration>0) (position.toFloat()/duration).coerceIn(0f,1f) else 0f,onValueChange={if(duration>0)c.seekTo((it*duration).toLong())})
                        Text(clock(position,pd)+" / "+clock(duration,pd))
                        Row { TextButton(onClick={c.seekToPreviousMediaItem()}){Text("⏮")}; TextButton(onClick={if(c.isPlaying)c.pause() else c.play();playerRevision++}){Text(if(c.isPlaying) "❚❚" else "▶")}; TextButton(onClick={c.seekToNextMediaItem()}){Text("⏭")} }
                        Row { TextButton(onClick={c.shuffleModeEnabled=!c.shuffleModeEnabled;playerRevision++}){Text(tr(fa,"Shuffle","تصادفی")+if(c.shuffleModeEnabled) " ✓" else "")}; TextButton(onClick={c.repeatMode=(c.repeatMode+1)%3;playerRevision++}){Text(tr(fa,"Repeat ","تکرار ")+digits(c.repeatMode,pd))} }
                        TextButton(onClick={ val speed=if(c.playbackParameters.speed>=1.5f) .75f else c.playbackParameters.speed+.25f;c.setPlaybackSpeed(speed);playerRevision++ }){Text(tr(fa,"Speed: ","سرعت: ")+digits(c.playbackParameters.speed,pd)+"×")}
                    }
                },confirmButton={TextButton(onClick={playerOpen=false}){Text(tr(fa,"Close","بستن"))}})
            }
        }
    }
}
