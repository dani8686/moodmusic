package com.daniel.mood

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "songs", indices = [Index("mood"), Index("artist"), Index("title"), Index("seen")])
data class Song(
    @PrimaryKey val id: Long,
    val uri: String, val title: String, val artist: String, val album: String,
    val duration: Long, val size: Long, val modified: Long, val added: Long,
    val mood: Int, val secondary: Int, val confidence: Float, val bpm: Float,
    val energy: Float, val reason: String, val manual: Boolean, val seen: Long
)

data class MoodCount(val mood: Int, val count: Int)
@Dao interface SongDao {
    @Query("SELECT * FROM songs WHERE id=:id") suspend fun get(id: Long): Song?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(song: Song)
    @Query("UPDATE songs SET seen=:seen WHERE id=:id") suspend fun touch(id: Long, seen: Long)
    @Query("DELETE FROM songs WHERE seen != :seen") suspend fun prune(seen: Long)
    @Query("SELECT mood, COUNT(*) AS count FROM songs GROUP BY mood") fun counts(): Flow<List<MoodCount>>
    @Query("SELECT * FROM songs WHERE (:mood = -1 OR mood = :mood) AND (title LIKE '%' || :query || '%' OR artist LIKE '%' || :query || '%') ORDER BY CASE WHEN :sort = 0 THEN title END COLLATE NOCASE, CASE WHEN :sort = 1 THEN artist END COLLATE NOCASE, CASE WHEN :sort = 2 THEN added END DESC, CASE WHEN :sort = 3 THEN bpm END DESC, CASE WHEN :sort = 4 THEN energy END DESC, id LIMIT :limit OFFSET :offset")
    fun page(mood: Int, query: String, sort: Int, limit: Int, offset: Int): Flow<List<Song>>
    @Query("SELECT * FROM songs WHERE (:mood = -1 OR mood = :mood) ORDER BY title COLLATE NOCASE") suspend fun playlist(mood: Int): List<Song>
    @Query("UPDATE songs SET mood=:mood, manual=1 WHERE id=:id") suspend fun correct(id: Long, mood: Int)
    @Query("UPDATE songs SET modified=-1 WHERE id=:id") suspend fun invalidate(id: Long)
    @Query("UPDATE songs SET modified=-1") suspend fun invalidateAll()
}
@Database(entities = [Song::class], version = 1, exportSchema = false)
abstract class MoodDatabase : RoomDatabase() {
    abstract fun songs(): SongDao
    companion object {
        @Volatile private var instance: MoodDatabase? = null
        fun get(context: Context): MoodDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, MoodDatabase::class.java, "moods.db").build().also { instance = it }
        }
    }
}
